import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.KeySpec;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;


public class Encryption_JavaCompute extends MbJavaComputeNode {
	private static SecretKeySpec secretKey;
	private static byte[] key;

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");


		MbMessage inMessage = inAssembly.getMessage();
		MbElement rootElem = inMessage.getRootElement().getFirstElementByPath("XMLNSC").getFirstElementByPath("RequestData");

		String msg 	= rootElem.getFirstElementByPath("msg").getValueAsString().toString();
		String key 	= rootElem.getFirstElementByPath("key").getValueAsString().toString();
		String operation = rootElem.getFirstElementByPath("operation").getValueAsString().toString();
		String method 	= rootElem.getFirstElementByPath("method").getValueAsString().toString();
		String salt 	= rootElem.getFirstElementByPath("salt").getValueAsString().toString();

		MbMessage outMessage = new MbMessage(inMessage); 
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly,outMessage);
		MbElement root = outMessage.getRootElement(); 

		try {
			// create new message as a copy of the input
			//	MbMessage outMessage = new MbMessage(inMessage);
			outAssembly = new MbMessageAssembly(inAssembly, outMessage);
			// ----------------------------------------------------------

			MbElement OutputRoot = root.getFirstElementByPath("XMLNSC").getFirstElementByPath("RequestData");
			OutputRoot.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "ResponseData", null);

			if (operation.equalsIgnoreCase("encryption") && method.equalsIgnoreCase("ECB"))
				OutputRoot.getFirstElementByPath("ResponseData").createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "msg", encrypt(msg, key));
			else if (operation.equalsIgnoreCase("decryption") && method.equalsIgnoreCase("ECB")) {
				OutputRoot.getFirstElementByPath("ResponseData").createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "msg", decrypt(msg, key));
			}
			else if (operation.equalsIgnoreCase("encryption") && method.equalsIgnoreCase("CBC")) {
				OutputRoot.getFirstElementByPath("ResponseData").createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "msg", encryptCBC(msg, key, salt));
			}
			else if (operation.equalsIgnoreCase("decryption") && method.equalsIgnoreCase("CBC")) {
				OutputRoot.getFirstElementByPath("ResponseData").createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "msg", decryptCBC(msg, key, salt));
			}
			out.propagate(outAssembly);
			// ----------------------------------------------------------
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} 

		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 



	}

	/*
	 * Method for Create Encryption and decryption key
	 */


	public static void setKey(String secKey) 
	{
		MessageDigest sha = null;
		try 
		{

			key = secKey.getBytes("UTF-8");
			sha = MessageDigest.getInstance("SHA-1");
			key = sha.digest(key);
			key = Arrays.copyOf(key, 16);
			secretKey = new SecretKeySpec(key, "AES");
			String secretKeyString = 
					Base64.getEncoder().encodeToString(secretKey.getEncoded());
			System.out.println("generated key = "+secretKeyString);
		}
		catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
	/**
	 * Method for Encrypt Plain String Data
	 * @param strToEncrypt
	 * @return String
	 */

	public static String encrypt(String strToEncrypt, String secKey)
	{
		String strEncrypt=null;
		try
		{
			setKey(secKey);
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, secretKey);
			strEncrypt =  Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes("UTF-8")));
			return strEncrypt;
		}
		catch (Exception e)
		{
			//logger.error("Error while encrypting: " ,e.toString());
		}
		return strEncrypt;
	}

	/**
	 * Method for decrypt Encrypted String Data
	 * @param strToDecrypt
	 * @return String
	 */

	public static String decrypt(String strToDecrypt, String secKey)
	{
		String strDecrypt=null;
		try
		{
			setKey(secKey);
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
			cipher.init(Cipher.DECRYPT_MODE, secretKey);
			strDecrypt=new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
			return strDecrypt;
		}
		catch (Exception e)
		{
			//logger.error("Error while decrypting: " , e.toString());
		}
		return strDecrypt;
	}

	
	public static String encryptCBC(String strToEncrypt, String key, String salt) {
	    try {
	      byte[] iv = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	      IvParameterSpec ivspec = new IvParameterSpec(iv);
	 
	      SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
	      KeySpec spec = new PBEKeySpec(key.toCharArray(), salt.getBytes(), 65536, 256);
	      SecretKey tmp = factory.generateSecret(spec);
	      SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");
	 
	      Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
	      cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivspec);
	      
	      System.out.println("String to encrypt....."+strToEncrypt);
	      
	      String encText = Base64.getEncoder()
	          .encodeToString(cipher.doFinal(strToEncrypt.getBytes(StandardCharsets.UTF_8)));
	      System.out.println("Encrypted string....."+encText);
	      
	      String encodedString = Base64.getEncoder().encodeToString(encText.getBytes()); 
		  System.out.println("Encrypted string after encoding....."+encodedString);
		
		  return encodedString;
	    } catch (Exception e) {
	      System.out.println("Error while encrypting: " + e.toString());
	    }
	    return null;
	  }
	
	
	public static String decryptCBC(String strToDecrypt, String key, String salt) {
	    try {
	      byte[] iv = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	      IvParameterSpec ivspec = new IvParameterSpec(iv);
	 
	      SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
	      KeySpec spec = new PBEKeySpec(key.toCharArray(), salt.getBytes(), 65536, 256);
	      SecretKey tmp = factory.generateSecret(spec);
	      SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");
	 
	      Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
	      cipher.init(Cipher.DECRYPT_MODE, secretKey, ivspec);
	      
	      System.out.println("Encrypted string to decrypt....."+strToDecrypt);
	      
	      byte[] decodedBytes  = Base64.getDecoder().decode(strToDecrypt);  
		  String decodedString = new String(decodedBytes);
		  System.out.println("Encrypted string after decoding....."+decodedString);
	      
	      String decStr= new String(cipher.doFinal(Base64.getDecoder().decode(decodedString)));
	      System.out.println("Decrypted string ....."+decStr);
	      
	      return decStr;
	      
	    } catch (Exception e) {
	      System.out.println("Error while decrypting: " + e.toString());
	    }
	    return null;
	  }
	
	
	public static void main(String args[]) {
		String plainText = "prabhasushmakarri@gmail.com|9494941942|29-Aug-2023 04:44:14 PM|4-14867877211|AS Addition|0005";
		String key = "@EME$$!NTE9SSR@T!0N";
		//String operation = "encryption";
		//String method = "EBC";
		String salt = "134567@987";

		try {
			//System.out.println("Input Data......................." + plainText);
			String encText, decText;
			//encText = encrypt(plainText, key);
			//System.out.println("Encrypted EBC Text......................." + encText);
			
			//decText = decrypt(encText, key);
			//System.out.println("Decrypted EBC Text......................." + decText);
			
			
			encText = encryptCBC(plainText, key, salt);
			//System.out.println("Encrypted CBC Text......................." + encText);
			
					
			decText = decryptCBC(encText, key, salt);
			System.out.println("Decrypted CBC Text......................." + decText);
			
		} catch (Exception e) {
			System.out.println("Ex :" + e);
		}
	}
}